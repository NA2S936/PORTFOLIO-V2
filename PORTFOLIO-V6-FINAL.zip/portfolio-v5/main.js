/* ── DARK MODE ── */
const toggle = document.getElementById('darkToggle');
const app = document.getElementById('app');
if (localStorage.getItem('dark') === '1') {
  app.classList.add('dark');
  if (toggle) toggle.classList.add('on');
}
if (toggle) {
  toggle.addEventListener('click', () => {
    app.classList.toggle('dark');
    toggle.classList.toggle('on');
    localStorage.setItem('dark', app.classList.contains('dark') ? '1' : '0');
  });
}

/* ── HAMBURGER MENU ── */
const hamburger = document.getElementById('hamburger');
const mobileMenu = document.getElementById('mobileMenu');
if (hamburger && mobileMenu) {
  hamburger.addEventListener('click', () => {
    mobileMenu.classList.toggle('open');
  });
  mobileMenu.querySelectorAll('a').forEach(a => {
    a.addEventListener('click', () => mobileMenu.classList.remove('open'));
  });
}

/* ── CODE RAIN ── */
const CODE_LINES = [
  "const fetchData = async (url) => {",
  "  const res = await fetch(url);",
  "  return res.json();",
  "};",
  "function Router({ page, setPage }) {",
  "  return <nav onClick={() => setPage('accueil')} />;",
  "}",
  "SELECT u.nom, s.entreprise FROM stages s",
  "JOIN utilisateurs u ON u.id = s.user_id",
  "WHERE s.annee = 2026;",
  "<?php",
  "  $pdo = new PDO($dsn, $user, $pass);",
  "  $stmt = $pdo->prepare('SELECT * FROM stages');",
  "  $stmt->execute();",
  "  $data = $stmt->fetchAll(PDO::FETCH_ASSOC);",
  "?>",
  "import { useState, useEffect } from 'react';",
  "const [dark, setDark] = useState(false);",
  "useEffect(() => { document.title = 'Nassim HB'; }, []);",
  "git commit -m 'feat: add dark mode toggle'",
  "git push origin main",
  "npm install && npm run dev",
  "class StageController extends Controller {",
  "  public function index() {",
  "    return view('stages.index');",
  "  }",
  "}",
  "const map = L.map('map').setView([48.85, 2.35], 13);",
  "L.tileLayer('https://{s}.tile.openstreetmap.org/').addTo(map);",
  "marker.bindPopup('<b>Rapport #42</b>').openPopup();",
  "def parse_exif(image_path):",
  "  img = Image.open(image_path)",
  "  exif = img._getexif()",
  "  return exif.get(34853)",
  "INSERT INTO rapports (lat, lng, date)",
  "VALUES (48.8566, 2.3522, NOW());",
  "CREATE TABLE stages (id INT PRIMARY KEY,",
  "  entreprise VARCHAR(255), debut DATE);",
  "// Géolocalisation via métadonnées EXIF",
  "// Workflow ComfyUI → n8n → Kling AI",
  "// BTS SIO SLAM · Promo 2026 · Nassim HB",
];

function initCodeRain(canvas) {
  if (!canvas) return;
  const ctx = canvas.getContext('2d');
  let cols = [], animId;
  const FONT_SIZE = 13;

  function init() {
    canvas.width = canvas.offsetWidth;
    canvas.height = canvas.offsetHeight;
    const numCols = Math.max(4, Math.floor(canvas.width / 180));
    cols = Array.from({ length: numCols }, (_, i) => ({
      x: (i / numCols) * canvas.width + 10,
      y: -50 - Math.random() * canvas.height,
      lineIdx: Math.floor(Math.random() * CODE_LINES.length),
      speed: 0.5 + Math.random() * 0.6,
      opacity: 0.32 + Math.random() * 0.15,
    }));
  }

  function draw() {
    const isDark = document.getElementById('app').classList.contains('dark');
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.font = `${FONT_SIZE}px 'Courier New', monospace`;
    cols.forEach(col => {
      for (let k = 0; k <= 6; k++) {
        const line = CODE_LINES[(col.lineIdx + k) % CODE_LINES.length];
        const fade = col.opacity * (1 - k * 0.12);
        ctx.fillStyle = isDark
          ? `rgba(160,100,255,${fade})`
          : `rgba(0,100,255,${fade})`;
        ctx.fillText(line, col.x, col.y + k * (FONT_SIZE + 8));
      }
      col.y += col.speed;
      if (col.y > canvas.height + 100) {
        col.y = -80 - Math.random() * 200;
        col.lineIdx = Math.floor(Math.random() * CODE_LINES.length);
        col.opacity = 0.32 + Math.random() * 0.15;
      }
    });
    animId = requestAnimationFrame(draw);
  }

  init();
  draw();
  const ro = new ResizeObserver(init);
  ro.observe(canvas);
}

document.querySelectorAll('canvas.code-rain').forEach(initCodeRain);

/* ── SCROLL REVEAL ── */
const srObserver = new IntersectionObserver((entries) => {
  entries.forEach(e => { if (e.isIntersecting) { e.target.classList.add('visible'); srObserver.unobserve(e.target); } });
}, { threshold: 0.1 });
document.querySelectorAll('.sr, .sr-left, .sr-right, .sr-scale').forEach(el => srObserver.observe(el));

/* ── STAGE MODALS ── */
const STAGES_DATA = [
  {
    id: "geniusmarket",
    tagLbl: "Stage 2ème année",
    logoSrc: "assets/geniusmarket-logo.png",
    logoBg: "#fff",
    color: "#006fff",
    company: "GeniusMarket",
    location: "Boulogne-Billancourt",
    period: "Avril 2026 – Juin 2026 · 6 semaines",
    summary: "Développement web, mobile et intégration IA générative au sein d'une agence digitale.",
    stack: ["PHP","JavaScript","SQL","Git","Kling AI","HiggsField AI","Sora","Google Veo","ComfyUI / n8n"],
    projects: [
      {
        name: "Elite Inspection – Géolocalisation de rapports",
        logoSrc: "assets/elite-logo.webp",
        logoBg: "#fff",
        color: "#006fff",
        missions: [
          "Analyse du besoin : permettre au superviseur de visualiser sur une carte les photos prises par les inspecteurs.",
          "Développement d'une fonctionnalité de géolocalisation des photos : lecture des métadonnées GPS (EXIF).",
          "Intégration d'une carte interactive avec Leaflet.js, marqueurs positionnés aux coordonnées exactes.",
          "Développement d'un module d'archivage des rapports : organisation, stockage et récupération.",
          "Participation au développement d'une application mobile complémentaire pour les inspecteurs.",
        ],
        techno: ["PHP","MySQL","JavaScript","Leaflet.js","EXIF","Git"],
        bilan: "Ce projet m'a permis de maîtriser les métadonnées EXIF, les API cartographiques et d'approfondir mes compétences back-end en PHP/MySQL sur un cas concret en entreprise."
      },
      {
        name: "MIA – Model Intelligence Agency",
        logoSrc: "assets/mia-logo.png",
        logoBg: "#000",
        color: "#8b3dff",
        missions: [
          "Génération de mannequins virtuels réalistes via ComfyUI (Stable Diffusion) avec workflows custom.",
          "Automatisation des pipelines de génération avec n8n : connexion des outils IA entre eux.",
          "Intégration de Kling AI et HiggsField AI pour la génération de vidéos à partir des images.",
          "Tests et intégration de Google Veo et Sora pour la génération vidéo avancée.",
          "Développement d'une interface web de gestion des mannequins générés.",
        ],
        techno: ["ComfyUI","n8n","Kling AI","HiggsField AI","Sora","Google Veo","JavaScript"],
        bilan: "Ce projet m'a plongé dans l'écosystème IA génératif de pointe. J'ai acquis une expertise sur les workflows de diffusion, l'automatisation avec n8n et les APIs vidéo IA."
      }
    ],
    bilan: "Ce stage m'a permis de travailler sur des projets concrets avec de vraies contraintes clients. J'ai renforcé mes compétences en développement web, découvert les API cartographiques et exploré la génération de contenu par IA."
  },
  {
    id: "ifeo",
    tagLbl: "Stage 1ère année",
    logoSrc: "assets/ifeo-logo.png",
    logoBg: "#000",
    color: "#059669",
    company: "IFEO Consulting",
    location: "Aulnay-sous-Bois",
    period: "Mai 2025 – Juin 2025 · 4 semaines",
    summary: "Interventions terrain chez des clients entreprises, gestion de tickets support et observation de négociation de partenariat commercial.",
    stack: ["Windows Server","Cisco","Switchs / Routeurs","Câblage RJ45","Ticketing","TCP/IP"],
    projects: [
      {
        name: "IFEO Consulting – Immersion complète en SSII",
        logoSrc: "assets/ifeo-logo.png",
        logoBg: "#000",
        color: "#059669",
        missions: [
          "ACSA : maintenance du parc informatique, remplacement de matériel défaillant et vérification des installations.",
          "Free Driver : installation d'une infrastructure réseau complète from scratch (câblage RJ45, switchs, routeurs Cisco, configuration TCP/IP).",
          "Gestion des tickets support : création, suivi et résolution de tickets pour les interventions clients.",
          "Accompagnement du dirigeant lors d'une réunion de négociation chez Unyc pour établir un partenariat commercial.",
        ],
        techno: ["Windows Server","Cisco","Switchs / Routeurs","Câblage RJ45","TCP/IP","GLPI"],
        bilan: "Premier contact avec le terrain professionnel : interventions chez des clients réels, compréhension du fonctionnement d'une SSII et participation à une vraie réunion de négociation commerciale."
      }
    ],
    bilan: "Ce premier stage m'a sorti du cadre scolaire pour me confronter à la réalité du terrain. J'ai compris comment fonctionne une SSII, l'importance du ticketing et j'ai assisté à une vraie négociation commerciale."
  }
];

function openStageModal(stageId) {
  const stage = STAGES_DATA.find(s => s.id === stageId);
  if (!stage) return;
  let activeProject = 0;

  function renderModal() {
    const proj = stage.projects[activeProject];
    const existing = document.getElementById('stageModalOverlay');
    if (existing) existing.remove();

    const overlay = document.createElement('div');
    overlay.id = 'stageModalOverlay';
    overlay.style.cssText = 'position:fixed;inset:0;background:rgba(4,4,10,0.7);backdrop-filter:blur(8px);z-index:999;display:flex;align-items:center;justify-content:center;padding:12px;animation:pfFadeIn .25s ease';
    overlay.addEventListener('click', () => overlay.remove());

    const tabs = stage.projects.length > 1 ? stage.projects.map((p, i) => `
      <button onclick="window._stageTab(${i})" style="padding:8px 16px;border-radius:999px;border:1.5px solid ${i===activeProject ? stage.color : 'rgba(0,0,0,0.1)'};background:${i===activeProject ? stage.color+'15' : 'transparent'};color:${i===activeProject ? stage.color : '#666'};font-weight:600;font-size:.8rem;cursor:pointer;">${p.name.split('–')[0].trim()}</button>`).join('') : '';

    overlay.innerHTML = `
    <div onclick="event.stopPropagation()" style="background:#fff;border-radius:20px;width:100%;max-width:820px;max-height:92vh;overflow-y:auto;box-shadow:0 40px 100px rgba(0,0,0,0.25);animation:pfSlideUp .35s cubic-bezier(.22,1,.36,1)">
      <div style="background:linear-gradient(135deg,${stage.color}15,${stage.color}05);border-bottom:1px solid rgba(0,0,0,0.06);padding:20px;border-radius:20px 20px 0 0;position:relative;">
        <button onclick="document.getElementById('stageModalOverlay').remove()" style="position:absolute;top:14px;right:14px;background:rgba(0,0,0,0.06);border:none;border-radius:50%;width:34px;height:34px;cursor:pointer;font-size:16px;display:flex;align-items:center;justify-content:center;">✕</button>
        <div style="display:flex;align-items:center;gap:14px;margin-bottom:14px;">
          <div style="width:52px;height:52px;border-radius:12px;background:${stage.logoBg};display:flex;align-items:center;justify-content:center;flex-shrink:0;padding:6px;border:1px solid rgba(0,0,0,0.08);">
            <img src="${stage.logoSrc}" alt="${stage.company}" style="width:100%;height:100%;object-fit:contain;"/>
          </div>
          <div>
            <span style="display:inline-block;font-size:.68rem;font-weight:700;text-transform:uppercase;letter-spacing:.08em;padding:3px 10px;border-radius:999px;background:${stage.color}15;color:${stage.color};margin-bottom:5px;">${stage.tagLbl}</span>
            <h2 style="font-family:'Syne',sans-serif;font-size:clamp(1.1rem,4vw,1.4rem);font-weight:800;">${stage.company} <span style="color:#888;font-weight:400;font-size:.9rem;">· ${stage.location}</span></h2>
            <p style="font-size:.82rem;color:#888;margin-top:2px;">${stage.period}</p>
          </div>
        </div>
        <p style="color:#555;font-size:.9rem;line-height:1.7;">${stage.summary}</p>
        <div style="display:flex;flex-wrap:wrap;gap:6px;margin-top:14px;">${stage.stack.map(t=>`<span style="font-size:.72rem;padding:4px 11px;border-radius:999px;background:rgba(0,0,0,0.05);font-weight:600;color:#444;">${t}</span>`).join('')}</div>
      </div>
      <div style="padding:20px;">
        ${tabs ? `<div style="display:flex;gap:8px;margin-bottom:20px;flex-wrap:wrap;">${tabs}</div>` : ''}
        <div style="display:flex;align-items:center;gap:12px;margin-bottom:16px;">
          <div style="width:44px;height:44px;border-radius:10px;background:${proj.logoBg};padding:5px;border:1px solid rgba(0,0,0,0.08);flex-shrink:0;">
            <img src="${proj.logoSrc}" alt="" style="width:100%;height:100%;object-fit:contain;"/>
          </div>
          <h3 style="font-family:'Syne',sans-serif;font-size:1rem;font-weight:800;">${proj.name}</h3>
        </div>
        <ul style="list-style:none;display:flex;flex-direction:column;gap:10px;margin-bottom:20px;">
          ${proj.missions.map(m=>`<li style="display:flex;gap:10px;font-size:.88rem;line-height:1.65;color:#444;"><span style="width:7px;height:7px;border-radius:50%;background:${proj.color};flex-shrink:0;margin-top:7px;"></span>${m}</li>`).join('')}
        </ul>
        <div style="display:flex;flex-wrap:wrap;gap:6px;margin-bottom:16px;">${proj.techno.map(t=>`<span style="font-size:.75rem;padding:4px 12px;border-radius:999px;background:${proj.color}12;color:${proj.color};font-weight:600;">${t}</span>`).join('')}</div>
        <div style="background:${proj.color}08;border-radius:12px;padding:14px 16px;border-left:3px solid ${proj.color};font-size:.87rem;color:#555;line-height:1.65;">${proj.bilan}</div>
      </div>
      <div style="padding:0 20px 20px;">
        <div style="background:rgba(0,0,0,0.03);border-radius:12px;padding:14px 16px;">
          <p style="font-size:.75rem;font-weight:700;text-transform:uppercase;letter-spacing:.06em;color:#888;margin-bottom:6px;">Bilan global du stage</p>
          <p style="font-size:.87rem;color:#555;line-height:1.65;">${stage.bilan}</p>
        </div>
      </div>
    </div>`;

    window._stageTab = (i) => { activeProject = i; renderModal(); };
    document.body.appendChild(overlay);
  }
  renderModal();
}

document.querySelectorAll('[data-stage]').forEach(el => {
  el.addEventListener('click', () => openStageModal(el.dataset.stage));
});

/* ── VEILLE MODALS ── */
const VEILLES_DATA = [
  {
    id: "ia-medecine",
    emoji: "🏥",
    color: "#006fff",
    titre: "IA dans la médecine",
    resume: "Comment l'intelligence artificielle transforme le diagnostic, l'imagerie médicale et la relation patient-médecin.",
    points: [
      "Détection des cancers (sein, poumon) : précision jusqu'à 4× supérieure à celle des radiologues humains.",
      "Réduction de 40% du temps d'analyse IRM grâce aux algorithmes de segmentation automatique.",
      "MedGPT et Synapse Medicine : assistants IA pour le diagnostic différentiel et les prescriptions.",
      "Doctolib intègre l'IA pour l'orientation des patients et la détection des consultations urgentes.",
      "Enjeux éthiques : responsabilité médicale, biais algorithmiques, protection des données de santé.",
    ],
    sources: [
      { label: "INSERM – IA et santé", url: "https://www.inserm.fr/dossier/intelligence-artificielle-et-sante/" },
      { label: "Nexa – IA médicale 2024", url: "https://nexa.polytech-lyon.fr/veille/ia-dans-le-domaine-medical/" },
      { label: "Aivancity – Diagnostic IA", url: "https://www.aivancity.ai/actualites/intelligence-artificielle-medecine" },
      { label: "Wikipedia – IA en médecine", url: "https://fr.wikipedia.org/wiki/Intelligence_artificielle_en_m%C3%A9decine" },
      { label: "Synapse Medicine – MedGPT", url: "https://synapse-medicine.com" },
    ]
  },
  {
    id: "chatgpt-atlas",
    emoji: "🌐",
    color: "#8b3dff",
    titre: "ChatGPT Atlas",
    resume: "Analyse de la nouvelle interface ChatGPT avec barre latérale persistante, mode Agent et ses implications pour la productivité.",
    points: [
      "Lancé le 21 octobre 2025 sur macOS : nouvelle barre latérale persistante pour l'historique et les projets.",
      "Mode Agent : ChatGPT peut exécuter des tâches complexes en plusieurs étapes de façon autonome.",
      "Intégration native aux applications macOS : accès rapide sans changer de fenêtre.",
      "Risques de sécurité : prompt injection via documents malveillants dans le mode Agent.",
      "Impact économique : annonce = -5% sur l'action Alphabet (Google) en une séance.",
    ],
    sources: [
      { label: "OpenAI – ChatGPT macOS", url: "https://openai.com/blog/chatgpt-macos" },
      { label: "Franceinfo – ChatGPT Atlas", url: "https://www.francetvinfo.fr/internet/intelligence-artificielle/chatgpt" },
      { label: "Adimeo – Analyse ChatGPT", url: "https://www.adimeo.com/blog/chatgpt-agent" },
      { label: "Minted – Mode Agent", url: "https://www.minted.fr/blog/chatgpt-agent-mode" },
      { label: "Jedha – Impact IA 2025", url: "https://www.jedha.co/blog/impact-ia-generative-2025" },
    ]
  },
  {
    id: "ia-sport",
    emoji: "⚽",
    color: "#059669",
    titre: "IA & Sport",
    resume: "L'IA au service de la performance sportive : analyse de données, prévention des blessures et arbitrage assisté.",
    points: [
      "Capteurs GPS et accéléromètres analysés par IA : optimisation des charges d'entraînement en temps réel.",
      "Réduction de 30% des blessures musculaires grâce aux modèles prédictifs (PSG, Manchester City).",
      "JO Paris 2024 : 20M€ investis dans des solutions IA pour l'analyse tactique et la sécurité.",
      "SkillCorner : IA d'analyse du positionnement et des déplacements en Ligue 1 et Premier League.",
      "Jumeaux numériques d'athlètes : simulation des performances pour optimiser la préparation.",
    ],
    sources: [
      { label: "EuropIA – IA et sport", url: "https://europia.org/intelligence-artificielle-sport/" },
      { label: "BPI France – Sport tech", url: "https://bpifrance.fr/nos-actualites/sport-tech-ia" },
      { label: "Management & Data Science", url: "https://www.management-datascience.org/articles/ia-sport/" },
      { label: "CrossData – Analytics sport", url: "https://crossdata.tech/blog/ia-sport-performance" },
      { label: "Win Sport School – IA formation", url: "https://www.winsportschool.com/blog/ia-sport" },
    ]
  },
  {
    id: "ia-emploi",
    emoji: "💼",
    color: "#d97706",
    titre: "IA & Emploi",
    resume: "L'impact de l'IA sur le marché du travail : quels métiers disparaissent, lesquels émergent, et comment se préparer.",
    points: [
      "Selon PwC AI Jobs Barometer : +78M d'emplois nets créés d'ici 2030 grâce à l'IA dans le monde.",
      "166 000 offres d'emploi mentionnant l'IA en France en 2024 (IT Social, 2025).",
      "Métiers les plus menacés : saisie de données, traduction simple, modération de contenu basique.",
      "Nouveaux métiers : Prompt Engineer, AI Trainer, LLMOps, AI Ethics Officer.",
      "59% des travailleurs envisagent une reconversion partielle pour s'adapter à l'IA (Labo Société Numérique).",
    ],
    sources: [
      { label: "PwC AI Jobs Barometer", url: "https://www.pwc.fr/fr/publications/intelligence-artificielle/ai-jobs-barometer.html" },
      { label: "IT Social – Emploi IA France", url: "https://itsocial.fr/enjeux-it/enjeux-rh/emploi/ia-et-emploi-les-chiffres-en-france/" },
      { label: "Franceinfo – IA et travail", url: "https://www.francetvinfo.fr/internet/intelligence-artificielle/ia-et-marche-du-travail" },
      { label: "Labo Société Numérique", url: "https://labo.societenumerique.gouv.fr/fr/articles/ia-et-emploi/" },
      { label: "Jedha – Métiers IA 2025", url: "https://www.jedha.co/blog/metiers-ia-futur" },
    ]
  }
];

function openVeilleModal(veilleId) {
  const v = VEILLES_DATA.find(x => x.id === veilleId);
  if (!v) return;
  const existing = document.getElementById('veilleModalOverlay');
  if (existing) existing.remove();

  const overlay = document.createElement('div');
  overlay.id = 'veilleModalOverlay';
  overlay.style.cssText = 'position:fixed;inset:0;background:rgba(4,4,10,0.7);backdrop-filter:blur(8px);z-index:999;display:flex;align-items:center;justify-content:center;padding:12px;animation:pfFadeIn .25s ease';
  overlay.addEventListener('click', () => overlay.remove());

  overlay.innerHTML = `
  <div onclick="event.stopPropagation()" style="background:#fff;border-radius:20px;width:100%;max-width:640px;max-height:90vh;overflow-y:auto;box-shadow:0 40px 100px rgba(0,0,0,0.25);animation:pfSlideUp .35s cubic-bezier(.22,1,.36,1)">
    <div style="background:linear-gradient(135deg,${v.color}15,${v.color}05);border-bottom:1px solid rgba(0,0,0,0.06);padding:24px;border-radius:20px 20px 0 0;position:relative;">
      <button onclick="document.getElementById('veilleModalOverlay').remove()" style="position:absolute;top:14px;right:14px;background:rgba(0,0,0,0.06);border:none;border-radius:50%;width:34px;height:34px;cursor:pointer;font-size:16px;display:flex;align-items:center;justify-content:center;">✕</button>
      <div style="font-size:2.2rem;margin-bottom:10px;">${v.emoji}</div>
      <h2 style="font-family:'Syne',sans-serif;font-size:1.4rem;font-weight:800;margin-bottom:8px;">${v.titre}</h2>
      <p style="color:#555;font-size:.9rem;line-height:1.65;">${v.resume}</p>
    </div>
    <div style="padding:24px;">
      <p style="font-size:.72rem;font-weight:700;text-transform:uppercase;letter-spacing:.08em;color:#aaa;margin-bottom:12px;">Points clés</p>
      <ul style="list-style:none;display:flex;flex-direction:column;gap:12px;margin-bottom:24px;">
        ${v.points.map(p=>`<li style="display:flex;gap:10px;font-size:.88rem;line-height:1.65;color:#444;"><span style="width:7px;height:7px;border-radius:50%;background:${v.color};flex-shrink:0;margin-top:7px;"></span>${p}</li>`).join('')}
      </ul>
      <p style="font-size:.72rem;font-weight:700;text-transform:uppercase;letter-spacing:.08em;color:#aaa;margin-bottom:12px;">Sources</p>
      <div style="display:flex;flex-direction:column;gap:8px;">
        ${v.sources.map(s=>`<a href="${s.url}" target="_blank" rel="noopener" style="display:flex;align-items:center;gap:10px;padding:10px 14px;border-radius:10px;border:1px solid rgba(0,0,0,0.07);background:rgba(0,0,0,0.02);text-decoration:none;color:#333;font-size:.85rem;font-weight:500;transition:background .2s;" onmouseover="this.style.background='${v.color}10'" onmouseout="this.style.background='rgba(0,0,0,0.02)'">${s.label} <span style="margin-left:auto;font-size:.72rem;color:#aaa;">↗</span></a>`).join('')}
      </div>
    </div>
  </div>`;

  document.body.appendChild(overlay);
}

document.querySelectorAll('[data-veille]').forEach(el => {
  el.addEventListener('click', () => openVeilleModal(el.dataset.veille));
});

/* ── CAROUSEL ── */
document.querySelectorAll('.carousel-track').forEach(track => {
  const clone = track.innerHTML;
  track.innerHTML += clone;
});

/* ── CONTACT FORM ── */
const contactForm = document.getElementById('contactForm');
if (contactForm) {
  contactForm.addEventListener('submit', (e) => {
    e.preventDefault();
    const nom = contactForm.querySelector('[name=nom]').value;
    const email = contactForm.querySelector('[name=email]').value;
    const sujet = contactForm.querySelector('[name=sujet]').value;
    const message = contactForm.querySelector('[name=message]').value;
    const mailto = `mailto:votre.email@exemple.com?subject=${encodeURIComponent(sujet||'Contact Portfolio')}&body=${encodeURIComponent(`Nom : ${nom}\nEmail : ${email}\n\n${message}`)}`;
    window.open(mailto);
    const msg = document.getElementById('successMsg');
    if (msg) { msg.style.display='flex'; setTimeout(()=>msg.style.display='none',4000); }
  });
}

/* ── ESCAPE KEY ── */
document.addEventListener('keydown', (e) => {
  if (e.key === 'Escape') {
    document.getElementById('stageModalOverlay')?.remove();
    document.getElementById('veilleModalOverlay')?.remove();
    document.getElementById('mobileMenu')?.classList.remove('open');
  }
});

/* ── SYNC BOTH DARK TOGGLES ── */
const toggle2 = document.getElementById('darkToggle2');
if (toggle2) {
  if (app.classList.contains('dark')) toggle2.classList.add('on');
  toggle2.addEventListener('click', () => {
    app.classList.toggle('dark');
    toggle2.classList.toggle('on');
    if (toggle) toggle.classList.toggle('on', app.classList.contains('dark'));
    localStorage.setItem('dark', app.classList.contains('dark') ? '1' : '0');
  });
}
